ServerCleanup.bat
### Wipes all non-character data from a game.db (buildings, placeables, inventory, etc. will be removed and character feats and levels will remain)
- Run ServerCleanup.bat from the same folder as the game.db you want to wipe



CheckGameDB.bat
### How to check integrity of game.db files:
- Open the folder where the Conan Exiles game.db file is in windows explorer (typically <Steam Library Folder>\steamapps\common\Conan Exiles\ConanSandbox\Saved )
- Run CheckGameDB.bat
- Read the output to find which database files are corrupt